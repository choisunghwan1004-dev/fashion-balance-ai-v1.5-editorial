const form=document.querySelector('#profileForm'),status=document.querySelector('#profileStatus');
async function load(){try{const r=await fetch('/api/profile');const d=await r.json();if(!r.ok)throw Error(d.error||'조회 실패');for(const [k,v] of Object.entries(d)){if(form.elements[k])form.elements[k].value=v;}status.textContent='저장된 설정을 불러왔습니다.';}catch(e){status.textContent='설정 조회 오류: '+e.message+' (DB 업그레이드 확인)';}}
form.addEventListener('submit',async e=>{e.preventDefault();status.textContent='저장 중…';try{const body=Object.fromEntries(new FormData(form));const r=await fetch('/api/profile',{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)throw Error(d.error||'저장 실패');status.textContent='✓ 스타일 설정 저장 완료. 코디 추천 화면에 반영됩니다.';}catch(e){status.textContent='저장 오류: '+e.message;}});load();

// V1.7: 선택 사진은 메모리에서만 읽고 서버 DB에 사진 자체를 저장하지 않습니다.
function readPhoto(file){return new Promise((ok,fail)=>{const fr=new FileReader();fr.onload=()=>ok(fr.result);fr.onerror=()=>fail(Error('사진 읽기 실패'));fr.readAsDataURL(file)})}
for(const kind of ['face','body']){const file=document.getElementById(kind+'Photo'),preview=document.getElementById(kind+'Preview');file.addEventListener('change',()=>{if(file.files[0]){preview.src=URL.createObjectURL(file.files[0]);preview.hidden=false;}});document.getElementById(kind+'Analyze').addEventListener('click',async()=>{const out=document.getElementById('photoAnalysisStatus'),f=file.files[0];if(!f)return out.textContent='사진을 선택해 주세요.';if(!document.getElementById('profileConsent').checked)return out.textContent='사진 전송 동의가 필요합니다.';if(!['image/jpeg','image/png','image/webp'].includes(f.type)||f.size>3*1024*1024)return out.textContent='JPG/PNG/WEBP 3MB 이하 사진만 가능합니다.';out.textContent='분석 중…';try{const data=await readPhoto(f),r=await fetch('/api/vision/analyze',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({kind,data,consent:true})}),d=await r.json();if(!r.ok)throw Error(d.error||'분석 실패');const field=kind==='face'?'face_shape':'body_shape';form.elements[field].value=d.result[field];out.textContent=`AI 제안: ${d.result[field]} (추정 신뢰도 ${Math.round(d.result.confidence*100)}%). 사진 분석은 부정확할 수 있습니다. 선택값을 직접 확인·수정하고 '내 스타일 저장'을 눌러주세요.`;}catch(e){out.textContent=e.message+' 아래에서 직접 선택할 수 있습니다.'}})}

// V1.8: 이미지 선택과 기존 셀렉트를 양방향 동기화
const bodySelect=form.elements.body_shape;
const bodyOptions=[['슬림형','slim'],['보통형','average'],['통통형','fuller']];
const bodyGrid=document.querySelector('#bodyCardGrid');
bodyGrid.innerHTML=bodyOptions.map(([label,file])=>`<button type="button" class="body-card" data-value="${label}" aria-pressed="false"><img src="/images/body-${file}.svg" alt="${label}을 나타내는 단순 실루엣 그림"><span>${label}</span></button>`).join('');
function syncBodyCards(){bodyGrid.querySelectorAll('.body-card').forEach(btn=>{const selected=btn.dataset.value===bodySelect.value;btn.classList.toggle('selected',selected);btn.setAttribute('aria-pressed',String(selected));});}
bodyGrid.addEventListener('click',e=>{const btn=e.target.closest('.body-card');if(!btn)return;bodySelect.value=btn.dataset.value;syncBodyCards();status.textContent=`${btn.dataset.value} 선택됨 — '내 스타일 저장'을 누르면 저장됩니다.`;});
bodySelect.addEventListener('change',syncBodyCards);
// 비동기 조회 후 카드 표시도 동기화
const originalLoad=load;
const profileObserver=new MutationObserver(()=>syncBodyCards());
profileObserver.observe(status,{childList:true,characterData:true,subtree:true});
syncBodyCards();
