# Fashion Balance AI V1.9 설치·업데이트

## 기존 V1.8 업데이트 (Windows PowerShell)
1. 실행 중인 서버를 Ctrl+C로 종료합니다. 기존 프로젝트 전체 폴더와 MySQL fashion_balance DB를 백업합니다. MySQL Workbench의 Server → Data Export 기능을 사용해도 됩니다.
2. V1.9 ZIP을 **새 폴더**에 풉니다. 기존 .env 파일을 새 폴더의 package.json 옆에 복사합니다. 기존 public/uploads 폴더가 있으면 내용까지 새 폴더의 public/uploads로 복사합니다. 개인 사진과 DB는 배포 ZIP에 포함되지 않습니다.
3. MySQL Workbench에서 database/upgrade_v1_9.sql을 열어 실행합니다. 이 SQL은 V1.8 기준 **한 번만** 실행합니다. Duplicate column 오류가 나면 재실행을 멈추고 적용 상태를 확인하세요. 데이터 삭제문은 없습니다.
4. 새 폴더의 package.json이 보이는 위치에서 터미널을 엽니다.

```powershell
npm install
npm run migrate-photos
npm test
npm start
```

새 설치는 기존 안내에 따라 database/schema.sql 및 필요한 seed SQL을 먼저 실행하고, upgrade_v1_9.sql을 실행합니다. 기존 DB에 seed를 다시 실행하지 마세요.

## .env 추가 항목
기존 DB/OpenAI 설정은 유지합니다. .env.example의 V1.9 항목을 .env에 추가합니다.

- APP_BASE_URL: 가입 QR이 가리킬 실제 서버 주소. PC만 테스트하면 http://localhost:3000. 휴대폰은 localhost로 PC에 접근할 수 없습니다. 같은 Wi-Fi에서 PC의 실제 IPv4 주소를 사용합니다(예: http://192.168.0.10:3000). 이 예시 주소는 본인 PC 주소로 바꾸세요. PowerShell에서 ipconfig로 확인합니다.
- SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASSWORD, MAIL_FROM: 사용하는 메일 제공업체의 SMTP 설정. 587은 STARTTLS(SMTP_SECURE=false), 465는 TLS(SMTP_SECURE=true). 제공업체에 따라 앱 비밀번호가 필요합니다.
- ADMIN_EMAILS: 상품을 등록할 관리자 이메일. 쉼표로 구분. 해당 이메일도 실제 인증 로그인이 필요합니다.
- NODE_ENV=production: 실서비스는 APP_BASE_URL을 HTTPS 주소로 지정해야 시작됩니다. HTTPS에서 Secure 쿠키를 사용합니다.

메일 설정이 없으면 인증 메일 요청이 503 안내로 종료됩니다. 우회 로그인·고정 인증번호는 없습니다. 메일을 보낼 때마다 실제 인증 메일이 발송됩니다. 배포 전 운영 SMTP 설정이 필요합니다.

## 휴대폰
PC와 휴대폰을 같은 Wi-Fi에 연결하고 APP_BASE_URL을 PC 주소로 맞춘 뒤 서버를 다시 시작합니다. Windows 방화벽에서 본인이 사용하는 신뢰할 수 있는 사설 네트워크에만 Node.js 접속을 허용합니다. 휴대폰에서 해당 주소를 열고 가입하거나 PC 화면 QR을 스캔합니다. 인증 메일의 링크는 로그인할 **휴대폰 브라우저**에서 여세요. 메일 앱 내부 브라우저로 열면 그 브라우저에만 로그인됩니다.

## 기존 데이터 처리
기존 사용자 1의 데모 옷장·체형은 새 가입자에게 자동 이전하지 않습니다. 기존 데모 이메일로 계정을 탈취하지 못하도록 verified_at이 비어 있는 기존 사용자 이메일은 신규 인증 로그인을 차단합니다. 실제 소유자가 확정된 데이터의 이전은 DB 백업 및 소유자 확인 후 별도 수행해야 합니다.
샘플/쇼핑 상품(owner_user_id NULL)과 개인 상품(owner_user_id 인증 사용자 ID)은 분리합니다. 새 회원 옷장은 빈 상태로 시작합니다. 샘플을 본인 옷장에 추가한 경우에만 보유품으로 계산됩니다.
기존 public/uploads는 migrate-photos로 private/uploads로 이동해야 합니다. 소유자 확인이 안 되는 사진은 비공개 상태로만 보관하며 노출하지 않습니다. 파일이 여러 소유자에 연결돼 있으면 도구가 중단되므로 수동 확인이 필요합니다.

## 확인·복구
이메일 링크 인증 → 메인 이동 → 체형 선택 → 옷 사진 등록 → 추천 → 내 코디 이력을 확인합니다. 로그아웃 후 개인 API는 401이어야 합니다. 서로 다른 브라우저로 A/B 회원을 만들고 B에서 A의 사진 URL을 열면 404가 나야 합니다.
문제가 있으면 서버를 정지하고 백업한 V1.8 폴더와 DB를 함께 복구합니다. V1.8은 개인 데이터 보호가 미흡하므로 외부 공개하지 마세요.
