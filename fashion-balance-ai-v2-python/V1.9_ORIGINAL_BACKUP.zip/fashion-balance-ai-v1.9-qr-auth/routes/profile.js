const router=require('express').Router();
const db=require('../db');
const valid={face_shape:['미선택','둥근형','타원형','각진형','긴형','하트형'],body_shape:['미선택','직선형','상체강조형','하체강조형','허리강조형','균형형','슬림형','보통형','통통형'],undertone:['미선택','웜','쿨','뉴트럴'],preferred_fit:['편안한핏','슬림핏','루즈핏']};
router.get('/',async(req,res,next)=>{try{const [rows]=await db.execute('SELECT face_shape,body_shape,undertone,preferred_fit FROM style_profiles WHERE user_id=?',[req.user.id]);res.json(rows[0]||{face_shape:'미선택',body_shape:'미선택',undertone:'미선택',preferred_fit:'편안한핏'});}catch(e){next(e)}});
router.put('/',async(req,res,next)=>{try{const o={};for(const [key,choices] of Object.entries(valid)){if(!choices.includes(req.body[key]))return res.status(400).json({error:key+' 선택값 오류'});o[key]=req.body[key];}await db.execute(`INSERT INTO style_profiles(user_id,face_shape,body_shape,undertone,preferred_fit) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE face_shape=VALUES(face_shape),body_shape=VALUES(body_shape),undertone=VALUES(undertone),preferred_fit=VALUES(preferred_fit)`,[req.user.id,...Object.keys(valid).map(k=>o[k])]);res.json({saved:true,profile:o});}catch(e){next(e)}});
module.exports=router;
