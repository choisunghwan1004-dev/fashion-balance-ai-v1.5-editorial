const router=require('express').Router();
const allowed={garment:['category','color','pattern','season','name','confidence'],face:['face_shape','confidence'],body:['body_shape','confidence']};
const options={category:['모자','스카프','아우터','상의','하의','신발','가방','벨트','시계','주얼리','알 수 없음'],color:['베이지','화이트','네이비','브라운','블랙','그레이','알 수 없음'],pattern:['무지','스트라이프','체크','도트','프린트','기타','알 수 없음'],season:['봄','여름','가을','겨울','사계절','알 수 없음'],face_shape:['둥근형','타원형','각진형','긴형','하트형','미선택'],body_shape:['직선형','상체강조형','하체강조형','허리강조형','균형형','미선택']};
router.get('/status',(req,res)=>res.json({ai_enabled:!!process.env.OPENAI_API_KEY,model:process.env.OPENAI_VISION_MODEL||'gpt-4.1-mini'}));
router.post('/analyze',async(req,res)=>{
 const {data,kind,consent}=req.body||{};
 if(!allowed[kind]||consent!==true)return res.status(400).json({error:'분석 유형과 사진 전송 동의를 확인하세요.'});
 if(typeof data!=='string'||data.length>4300000||!/^data:image\/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$/.test(data))return res.status(400).json({error:'3MB 이하 JPG/PNG/WEBP 이미지만 가능합니다.'});
 const bytes=Buffer.from(data.split(',')[1],'base64');if(bytes.length>3*1024*1024||bytes.length<16)return res.status(400).json({error:'사진 용량을 확인하세요.'});
 const valid=data.startsWith('data:image/jpeg')?bytes.subarray(0,3).equals(Buffer.from([255,216,255])):data.startsWith('data:image/png')?bytes.subarray(0,8).equals(Buffer.from([137,80,78,71,13,10,26,10])):bytes.toString('ascii',0,4)==='RIFF'&&bytes.toString('ascii',8,12)==='WEBP';
 if(!valid)return res.status(400).json({error:'이미지 형식이 올바르지 않습니다.'});
 if(!process.env.OPENAI_API_KEY)return res.status(503).json({error:'AI 사진 분석 API 키가 없습니다. 수동 선택과 기기 내 색상 추정은 이용할 수 있습니다.',manual_fallback:true});
 const instructions={
 garment:'의류나 액세서리 사진을 보고 종류, 주요 색상, 패턴, 계절, 간단한 한국어 이름을 추정한다. color는 베이지/화이트/네이비/브라운/블랙/그레이/알 수 없음 중 하나. category는 모자/스카프/아우터/상의/하의/신발/가방/벨트/시계/주얼리/알 수 없음 중 하나. season은 봄/여름/가을/겨울/사계절/알 수 없음 중 하나. pattern은 무지/스트라이프/체크/도트/프린트/기타/알 수 없음 중 하나.',
 face:'사진에서 얼굴이 명확하게 보일 때만 얼굴 윤곽을 둥근형/타원형/각진형/긴형/하트형 중 하나로 추정한다. 얼굴이 불분명하면 미선택. 나이, 인종, 피부색, 미모 등은 추론하지 않는다.',
 body:'전신이 뚜렷하게 보이는 경우에만 의복의 시각적 실루엣을 직선형/상체강조형/하체강조형/허리강조형/균형형 중 하나로 추정한다. 실제 신체 치수나 건강, 체중은 추론하지 않는다. 불명확하면 미선택.'};
 const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),20000);
 try{
 const response=await fetch('https://api.openai.com/v1/responses',{method:'POST',signal:controller.signal,headers:{Authorization:'Bearer '+process.env.OPENAI_API_KEY,'Content-Type':'application/json'},body:JSON.stringify({model:process.env.OPENAI_VISION_MODEL||'gpt-4.1-mini',store:false,max_output_tokens:250,input:[{role:'user',content:[{type:'input_text',text:instructions[kind]+' JSON 객체만 반환해 주세요. confidence는 0~1의 추정 신뢰도입니다. 확실하지 않으면 알 수 없음/미선택을 선택하세요.'},{type:'input_image',image_url:data}]}]})});
 const raw=await response.json();if(!response.ok)return res.status(502).json({error:'AI 서비스 요청 실패: '+(raw.error?.message||response.status)});
 const txt=(raw.output||[]).flatMap(x=>x.content||[]).filter(x=>x.type==='output_text').map(x=>x.text).join('');
 const parsed=JSON.parse(txt.replace(/^```(?:json)?\s*|\s*```$/g,''));const result={};for(const field of allowed[kind]){const value=parsed[field];if(field==='confidence')result[field]=Math.min(1,Math.max(0,Number(value)||0));else if(field==='name')result.name=String(value||'내 옷').slice(0,80);else result[field]=options[field].includes(value)?value:options[field].at(-1)}
 res.json({result,requires_confirmation:true,stored:false});
 }catch(e){res.status(502).json({error:e.name==='AbortError'?'AI 응답 시간이 초과되었습니다.':'AI 응답을 처리할 수 없습니다. 직접 선택해 주세요.'});}finally{clearTimeout(timeout)}
});
module.exports=router;
