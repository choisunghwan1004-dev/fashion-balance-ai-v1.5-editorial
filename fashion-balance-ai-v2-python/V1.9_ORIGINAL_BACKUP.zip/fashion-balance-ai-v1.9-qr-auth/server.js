require('dotenv').config();
const express=require('express'),path=require('path'),fs=require('fs/promises'),db=require('./db'),auth=require('./services/auth');
auth.origin();const app=express();app.disable('x-powered-by');
app.use((req,res,next)=>{res.set('Referrer-Policy','no-referrer');res.set('X-Content-Type-Options','nosniff');if(req.path.startsWith('/api/')||req.path.startsWith('/uploads/'))res.set('Cache-Control','no-store');next();});
app.use(express.json({limit:'4.5mb'}));app.use(auth.sameOrigin);app.use(auth.identify);
app.use('/api/auth',require('./routes/auth'));
app.get('/uploads/:filename',auth.required,async(req,res,next)=>{try{if(!/^[a-f0-9-]+\.(jpg|png|webp)$/.test(req.params.filename))return res.sendStatus(404);const [r]=await db.execute('SELECT filename FROM private_photos WHERE filename=? AND user_id=?',[req.params.filename,req.user.id]);if(!r.length)return res.sendStatus(404);res.sendFile(path.join(__dirname,'private/uploads',req.params.filename));}catch(e){next(e);}});
// Block the old public directory, including encoded or nested requests.
app.use('/uploads',(req,res)=>res.sendStatus(404));
app.use(express.static(path.join(__dirname,'public')));
for(const route of ['vision','uploads','outfits','wardrobe','profile'])app.use('/api/'+route,auth.required,require('./routes/'+route));
app.use('/api/items',require('./routes/items'));app.use('/api/trends',require('./routes/trends'));app.use('/api/seasonal-looks',require('./routes/seasonal'));
app.use((err,req,res,next)=>{console.error('Request failed:',err.code||err.name);res.status(500).json({error:'서버 또는 DB 오류가 발생했습니다.'});});
if(require.main===module){fs.access(path.join(__dirname,'public/uploads')).then(()=>{throw Error('Run npm run migrate-photos before starting V1.9');}).catch(e=>{if(e.code!=='ENOENT'){console.error(e.message);process.exitCode=1;return;}app.listen(Number(process.env.PORT||3000),'0.0.0.0',()=>console.log('Fashion Balance AI V1.9: '+auth.origin()));});}
module.exports=app;
