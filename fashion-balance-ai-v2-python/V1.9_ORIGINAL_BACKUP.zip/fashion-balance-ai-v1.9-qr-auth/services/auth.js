const crypto=require('crypto');
const db=require('../db');
const hash=v=>crypto.createHash('sha256').update(v).digest('hex');
const token=()=>crypto.randomBytes(32).toString('hex');
function origin(){const u=new URL(process.env.APP_BASE_URL||'http://localhost:3000');if(process.env.NODE_ENV==='production'&&u.protocol!=='https:')throw Error('Production requires HTTPS APP_BASE_URL');return u.origin;}
function cookie(req){const m=/(?:^|;\s*)fashion_session=([a-f0-9]{64})(?:;|$)/.exec(req.headers.cookie||'');return m?m[1]:null;}
async function identify(req,res,next){try{const t=cookie(req);if(t){const [r]=await db.execute('SELECT u.id,u.email,u.nickname FROM auth_sessions s JOIN users u ON u.id=s.user_id WHERE s.token_hash=? AND s.expires_at>UTC_TIMESTAMP() AND u.verified_at IS NOT NULL',[hash(t)]);req.user=r[0];}next();}catch(e){next(e);}}
function required(req,res,next){if(!req.user)return res.status(401).json({error:'로그인이 필요합니다.'});next();}
function sameOrigin(req,res,next){if(['GET','HEAD','OPTIONS'].includes(req.method))return next();if(req.headers.origin!==origin())return res.status(403).json({error:'요청 출처를 확인하세요.'});next();}
function setCookie(res,t,age){res.cookie('fashion_session',t,{httpOnly:true,secure:origin().startsWith('https:'),sameSite:'lax',path:'/',maxAge:age});}
function admin(req,res,next){if(!req.user||!String(process.env.ADMIN_EMAILS||'').split(',').map(s=>s.trim().toLowerCase()).includes(req.user.email.toLowerCase()))return res.status(403).json({error:'관리자 권한이 필요합니다.'});next();}
async function limit(key,max){const bucket=hash(key),conn=await db.getConnection();try{await conn.beginTransaction();await conn.execute('INSERT INTO auth_limits(bucket,hits,expires_at) VALUES(?,1,DATE_ADD(UTC_TIMESTAMP(),INTERVAL 1 HOUR)) ON DUPLICATE KEY UPDATE hits=IF(expires_at<=UTC_TIMESTAMP(),1,hits+1),expires_at=IF(expires_at<=UTC_TIMESTAMP(),DATE_ADD(UTC_TIMESTAMP(),INTERVAL 1 HOUR),expires_at)',[bucket]);const [r]=await conn.execute('SELECT hits FROM auth_limits WHERE bucket=?',[bucket]);await conn.commit();return r[0].hits<=max;}catch(e){await conn.rollback();throw e;}finally{conn.release();}}
module.exports={hash,token,origin,identify,required,sameOrigin,setCookie,admin,limit};
